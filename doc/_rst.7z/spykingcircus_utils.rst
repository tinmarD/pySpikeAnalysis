spykingcircus\_utils module
===========================

.. automodule:: spykingcircus_utils
    :members:
    :undoc-members:
    :show-inheritance:
