eeg\_utils module
=================

.. automodule:: eeg_utils
    :members:
    :undoc-members:
    :show-inheritance:
