spikeAnalysis\_utils module
===========================

.. automodule:: spikeAnalysis_utils
    :members:
    :undoc-members:
    :show-inheritance:
