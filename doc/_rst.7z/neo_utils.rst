neo\_utils module
=================

.. automodule:: neo_utils
    :members:
    :undoc-members:
    :show-inheritance:
