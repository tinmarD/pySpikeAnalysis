neoStructures\_params module
============================

.. automodule:: neoStructures_params
    :members:
    :undoc-members:
    :show-inheritance:
